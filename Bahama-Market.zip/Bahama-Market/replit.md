# Bahama Market

Bahama Market is a mobile-first marketplace for people in The Bahamas to discover, list, save, and discuss local items using BSD pricing.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/bahama-market/app/` — Expo Router screens for Home, Search, Sell, Messages, Profile, listings, sellers, chats, and auth.
- `artifacts/bahama-market/components/MarketUI.tsx` — shared marketplace UI primitives and listing cards.
- `artifacts/bahama-market/constants/market.ts` — marketplace types and starter listings/conversations.
- `artifacts/bahama-market/context/MarketContext.tsx` — device-persisted listings, saved items, and conversations.
- `artifacts/bahama-market/constants/colors.ts` — Bahama Market semantic light/dark theme.

## Architecture decisions

- AsyncStorage remains the local cache/offline fallback, while Supabase is the cloud source of truth when the schema and Clerk JWT trust are configured.
- Clerk provides real account creation and sign-in; Supabase receives the Clerk JWT through the `supabase` template rather than introducing a second login system.
- Image selection and foreground location use Expo device capabilities rather than simulated permission flows.
- The Supabase schema, RLS policies, Realtime publication, and listing-images bucket setup live in `artifacts/bahama-market/supabase/schema.sql`.

## Product

Users can browse Nassau listings, search by category, save finds, open seller profiles, message sellers, create accounts, publish listings with a gallery photo and BSD price, and use device location to fill listing location.

## User preferences

 - Use BSD for all marketplace prices.
 - Keep the product mobile-first, simple, and useful for Android users in The Bahamas.

## Gotchas

 - The Expo dev script forwards the managed Clerk publishable key; production builds forward the proxy URL through the existing build script.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
