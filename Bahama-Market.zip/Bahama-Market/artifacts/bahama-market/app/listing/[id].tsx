import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React from 'react';
import { Image, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@clerk/clerk-expo';
import { Avatar, IconButton, PrimaryButton } from '@/components/MarketUI';
import { useColors } from '@/hooks/useColors';
import { useMarket } from '@/context/MarketContext';

export default function ListingDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { isSignedIn } = useAuth();
  const { listings, favorites, toggleFavorite, startConversation } = useMarket();
  const listing = listings.find((item) => item.id === id);
  if (!listing) return <View style={[styles.missing, { backgroundColor: colors.background }]}><Text style={[styles.missingText, { color: colors.foreground }]}>Listing not found</Text></View>;
  return <View style={[styles.container, { backgroundColor: colors.background }]}><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 25 }}><View style={styles.hero}><Image source={listing.image} style={styles.heroImage} /><View style={[styles.heroActions, { top: insets.top + 10 }]}><IconButton icon="arrow-back" label="Go back" onPress={() => router.back()} /><IconButton icon={favorites.includes(listing.id) ? 'heart' : 'heart-outline'} active={favorites.includes(listing.id)} label="Save listing" onPress={() => toggleFavorite(listing.id)} /></View></View><View style={styles.body}><View style={styles.statusLine}><Text style={[styles.status, { color: colors.primary }]}>{listing.condition}</Text><Text style={[styles.posted, { color: colors.mutedForeground }]}>{listing.postedAt}</Text></View><Text style={[styles.title, { color: colors.foreground }]}>{listing.title}</Text><Text style={[styles.price, { color: colors.foreground }]}>${listing.price.toLocaleString()} <Text style={[styles.currency, { color: colors.mutedForeground }]}>BSD</Text></Text><View style={styles.location}><Ionicons name="location-outline" size={17} color={colors.primary} /><Text style={[styles.locationText, { color: colors.mutedForeground }]}>{listing.location}, The Bahamas</Text></View><View style={[styles.divider, { backgroundColor: colors.border }]} /><Text style={[styles.sectionTitle, { color: colors.foreground }]}>About this item</Text><Text style={[styles.description, { color: colors.mutedForeground }]}>{listing.description}</Text><Pressable onPress={() => router.push(`/seller/${listing.seller.id}`)} style={[styles.sellerCard, { backgroundColor: colors.card, borderColor: colors.border }]}><Avatar seller={listing.seller} size={47} /><View style={styles.sellerCopy}><Text style={[styles.sellerName, { color: colors.foreground }]}>{listing.seller.name}</Text><View style={styles.rating}><Ionicons name="star" size={13} color={colors.accent} /><Text style={[styles.ratingText, { color: colors.mutedForeground }]}>{listing.seller.rating} · {listing.seller.sales}</Text></View></View><Ionicons name="chevron-forward" size={20} color={colors.mutedForeground} /></Pressable><PrimaryButton label={isSignedIn ? 'Message seller' : 'Sign in to message'} icon="chatbubble-ellipses-outline" onPress={() => { if (!isSignedIn) { router.push('/(auth)/sign-in'); return; } const conversationId = startConversation(listing); router.push(`/message/${conversationId}`); }} /></View></ScrollView></View>;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  hero: { height: 340, position: 'relative' },
  heroImage: { width: '100%', height: '100%' },
  heroActions: { position: 'absolute', left: 17, right: 17, flexDirection: 'row', justifyContent: 'space-between' },
  body: { padding: 19 },
  statusLine: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 9 },
  status: { fontSize: 11, fontFamily: 'Inter_700Bold', textTransform: 'uppercase', letterSpacing: 0.8 },
  posted: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  title: { fontSize: 26, lineHeight: 32, fontFamily: 'Inter_700Bold', letterSpacing: -0.7, marginBottom: 10 },
  price: { fontSize: 22, fontFamily: 'Inter_700Bold', marginBottom: 10 },
  currency: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  location: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  locationText: { fontSize: 12, fontFamily: 'Inter_500Medium' },
  divider: { height: 1, marginVertical: 21 },
  sectionTitle: { fontSize: 16, fontFamily: 'Inter_700Bold', marginBottom: 9 },
  description: { fontSize: 13, lineHeight: 20, fontFamily: 'Inter_400Regular', marginBottom: 20 },
  sellerCard: { borderRadius: 17, borderWidth: 1, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 18 },
  sellerCopy: { flex: 1 },
  sellerName: { fontSize: 13, fontFamily: 'Inter_700Bold', marginBottom: 5 },
  rating: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  ratingText: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  missing: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  missingText: { fontFamily: 'Inter_600SemiBold' },
});