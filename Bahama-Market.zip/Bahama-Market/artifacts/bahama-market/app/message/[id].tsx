import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useRef, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar } from '@/components/MarketUI';
import { useColors } from '@/hooks/useColors';
import { useMarket } from '@/context/MarketContext';

export default function MessageDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { conversations, sendMessage } = useMarket();
  const conversation = conversations.find((item) => item.id === id);
  const [draft, setDraft] = useState('');
  const inputRef = useRef<TextInput>(null);
  if (!conversation) return <View style={[styles.missing, { backgroundColor: colors.background }]}><Text style={{ color: colors.foreground }}>Conversation not found</Text></View>;
  const send = () => { if (!draft.trim()) return; sendMessage(conversation.id, draft.trim()); setDraft(''); inputRef.current?.focus(); };
  return <KeyboardAvoidingView style={[styles.container, { backgroundColor: colors.background }]} behavior="padding" keyboardVerticalOffset={0}><View style={[styles.header, { paddingTop: insets.top + 10, borderBottomColor: colors.border }]}><Pressable onPress={() => router.back()} style={styles.back}><Ionicons name="arrow-back" size={21} color={colors.foreground} /></Pressable><Avatar seller={conversation.seller} size={39} /><View style={styles.headerCopy}><Text style={[styles.headerName, { color: colors.foreground }]}>{conversation.seller.name}</Text><Text style={[styles.headerListing, { color: colors.primary }]}>{conversation.listingTitle}</Text></View><Ionicons name="ellipsis-horizontal" size={20} color={colors.mutedForeground} /></View><FlatList data={conversation.messages.slice().reverse()} inverted keyExtractor={(item) => item.id} contentContainerStyle={styles.messages} keyboardDismissMode="interactive" keyboardShouldPersistTaps="handled" renderItem={({ item }) => <View style={[styles.bubbleRow, item.fromMe && styles.myBubbleRow]}><View style={[styles.bubble, { backgroundColor: item.fromMe ? colors.primary : colors.card, borderColor: colors.border }]}><Text style={[styles.bubbleText, { color: item.fromMe ? colors.primaryForeground : colors.foreground }]}>{item.text}</Text><Text style={[styles.bubbleTime, { color: item.fromMe ? colors.secondary : colors.mutedForeground }]}>{item.time}</Text></View></View>} ListEmptyComponent={<View style={styles.start}><Ionicons name="chatbubble-ellipses-outline" size={28} color={colors.primary} /><Text style={[styles.startText, { color: colors.mutedForeground }]}>Say hello to {conversation.seller.name.split(' ')[0]}.</Text></View>} /><View style={[styles.composer, { paddingBottom: insets.bottom + 8, borderTopColor: colors.border }]}><TextInput ref={inputRef} testID="message-input" value={draft} onChangeText={setDraft} placeholder="Write a message…" placeholderTextColor={colors.mutedForeground} style={[styles.messageInput, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]} /><Pressable testID="send-message" onPress={send} style={[styles.send, { backgroundColor: colors.primary, opacity: draft.trim() ? 1 : 0.45 }]} disabled={!draft.trim()}><Ionicons name="arrow-up" size={19} color={colors.primaryForeground} /></Pressable></View></KeyboardAvoidingView>;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { minHeight: 70, paddingHorizontal: 16, borderBottomWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  back: { padding: 6, marginRight: 1 },
  headerCopy: { flex: 1 },
  headerName: { fontSize: 14, fontFamily: 'Inter_700Bold', marginBottom: 3 },
  headerListing: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  messages: { paddingHorizontal: 17, paddingTop: 15, paddingBottom: 15 },
  bubbleRow: { alignItems: 'flex-start', marginVertical: 5 },
  myBubbleRow: { alignItems: 'flex-end' },
  bubble: { maxWidth: '78%', borderRadius: 17, borderWidth: 1, paddingHorizontal: 13, paddingVertical: 10 },
  bubbleText: { fontSize: 13, lineHeight: 19, fontFamily: 'Inter_400Regular' },
  bubbleTime: { fontSize: 9, fontFamily: 'Inter_500Medium', marginTop: 5, textAlign: 'right' },
  composer: { borderTopWidth: 1, paddingTop: 10, paddingHorizontal: 14, flexDirection: 'row', gap: 9, alignItems: 'center' },
  messageInput: { minHeight: 46, flex: 1, borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, fontSize: 13, fontFamily: 'Inter_400Regular' },
  send: { width: 44, height: 44, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  start: { transform: [{ scaleY: -1 }], alignItems: 'center', paddingTop: 35 },
  startText: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 9 },
  missing: { flex: 1, alignItems: 'center', justifyContent: 'center' },
});