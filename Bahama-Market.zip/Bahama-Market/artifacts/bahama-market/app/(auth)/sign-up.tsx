import * as AuthSession from 'expo-auth-session';
import * as WebBrowser from 'expo-web-browser';
import { useSSO, useSignUp } from '@clerk/clerk-expo';
import { Link, useRouter } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { LogoMark, PrimaryButton } from '@/components/MarketUI';
import { useColors } from '@/hooks/useColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

function getErrorMessage(error: unknown) {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === 'object' && error !== null && 'message' in error && typeof error.message === 'string') return error.message;
  return 'Could not complete account setup. Please try again.';
}

export default function SignUpScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { isLoaded, signUp, setActive } = useSignUp();
  const { startSSOFlow } = useSSO();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const fetchStatus = isSubmitting || !isLoaded ? 'fetching' : 'idle';
  const errors = { fields: { emailAddress: authError ? { message: authError } : undefined } };
  const signInWithGoogle = useCallback(async () => {
    try {
      const { createdSessionId, setActive } = await startSSOFlow({ strategy: 'oauth_google', redirectUrl: AuthSession.makeRedirectUri({ scheme: 'bahama-market' }) });
      if (createdSessionId && setActive) { await setActive({ session: createdSessionId }); router.replace('/'); }
    } catch { Alert.alert('Could not connect', 'Please try again or use email and password.'); }
  }, [router, startSSOFlow]);
  const submit = async () => {
    if (!isLoaded || !signUp || !setActive) return;
    setIsSubmitting(true);
    setAuthError(null);
    const [firstName, ...rest] = name.trim().split(' ');
    try {
      const result = await signUp.create({ emailAddress: email.trim(), password, firstName, lastName: rest.join(' ') });
      if (result.status === 'complete' && result.createdSessionId) {
        await setActive({ session: result.createdSessionId });
        router.replace('/');
        return;
      }
      await signUp.prepareEmailAddressVerification({ strategy: 'email_code' });
      setVerifying(true);
    } catch (error) {
      setAuthError(getErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  };
  const verify = async () => {
    if (!isLoaded || !signUp || !setActive) return;
    setIsSubmitting(true);
    setAuthError(null);
    try {
      const result = await signUp.attemptEmailAddressVerification({ code });
      if (result.status === 'complete' && result.createdSessionId) {
        await setActive({ session: result.createdSessionId });
        router.replace('/');
      } else {
        setAuthError('Email verification is not complete. Check the code and try again.');
      }
    } catch (error) {
      setAuthError(getErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  };
  const resendVerification = async () => {
    if (!isLoaded || !signUp) return;
    setIsSubmitting(true);
    setAuthError(null);
    try {
      await signUp.prepareEmailAddressVerification({ strategy: 'email_code' });
    } catch (error) {
      setAuthError(getErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  };
  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingTop: insets.top + 25, paddingHorizontal: 23, paddingBottom: insets.bottom + 25 }}
      bottomOffset={25}
      keyboardShouldPersistTaps="handled"
    >
      <Pressable onPress={() => router.back()} style={styles.close}>
        <Text style={[styles.closeText, { color: colors.mutedForeground }]}>Close</Text>
      </Pressable>
      <LogoMark />
      <Text style={[styles.title, { color: colors.foreground }]}>{verifying ? 'One last step.' : 'Join the market.'}</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
        {verifying ? 'Enter the code we sent to your email.' : 'Buy local, sell easily, and keep it Bahamian.'}
      </Text>

      {verifying ? (
        <>
          <TextInput
            testID="verification-code"
            value={code}
            onChangeText={setCode}
            keyboardType="number-pad"
            placeholder="Enter verification code"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]}
          />
          <PrimaryButton label="Verify my account" onPress={verify} disabled={!code || fetchStatus === 'fetching'} />
          <Pressable onPress={resendVerification} disabled={fetchStatus === 'fetching'}>
            <Text style={[styles.resend, { color: colors.primary }]}>Send a new code</Text>
          </Pressable>
        </>
      ) : (
        <>
          <Pressable
            testID="google-sign-up"
            onPress={signInWithGoogle}
            style={[styles.googleButton, { backgroundColor: colors.card, borderColor: colors.border }]}
          >
            <Text style={[styles.googleG, { color: colors.primary }]}>G</Text>
            <Text style={[styles.googleText, { color: colors.foreground }]}>Continue with Google</Text>
          </Pressable>
          <View style={styles.divider}>
            <View style={[styles.line, { backgroundColor: colors.border }]} />
            <Text style={[styles.or, { color: colors.mutedForeground }]}>or use email</Text>
            <View style={[styles.line, { backgroundColor: colors.border }]} />
          </View>
          <Text style={[styles.label, { color: colors.foreground }]}>Your name</Text>
          <TextInput
            testID="sign-up-name"
            value={name}
            onChangeText={setName}
            placeholder="First and last name"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]}
          />
          <Text style={[styles.label, { color: colors.foreground }]}>Email address</Text>
          <TextInput
            testID="sign-up-email"
            autoCapitalize="none"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
            placeholder="you@example.com"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]}
          />
          <Text style={[styles.label, { color: colors.foreground }]}>Password</Text>
          <TextInput
            testID="sign-up-password"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
            placeholder="At least 8 characters"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]}
          />
          <PrimaryButton label="Create account" onPress={submit} disabled={!name || !email || !password || fetchStatus === 'fetching'} />
          <View nativeID="clerk-captcha" />
        </>
      )}
      {errors.fields.emailAddress && <Text style={[styles.error, { color: colors.destructive }]}>{errors.fields.emailAddress.message}</Text>}
      <View style={styles.footer}>
        <Text style={[styles.footerText, { color: colors.mutedForeground }]}>Already have an account?</Text>
        <Link href="/(auth)/sign-in" asChild>
          <Pressable><Text style={[styles.link, { color: colors.primary }]}> Sign in</Text></Pressable>
        </Link>
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  close: { alignSelf: 'flex-end', paddingVertical: 8, marginBottom: 22 },
  closeText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  title: { fontSize: 30, fontFamily: 'Inter_700Bold', letterSpacing: -1, marginTop: 41, marginBottom: 7 },
  subtitle: { fontSize: 14, fontFamily: 'Inter_400Regular', marginBottom: 28 },
  googleButton: { minHeight: 51, borderRadius: 15, borderWidth: 1, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9 },
  googleG: { fontSize: 17, fontFamily: 'Inter_700Bold' },
  googleText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  divider: { flexDirection: 'row', alignItems: 'center', gap: 9, marginVertical: 21 },
  line: { height: 1, flex: 1 },
  or: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  label: { fontSize: 12, fontFamily: 'Inter_700Bold', marginBottom: 8 },
  input: { minHeight: 51, borderRadius: 15, borderWidth: 1, paddingHorizontal: 14, fontSize: 14, fontFamily: 'Inter_500Medium', marginBottom: 17 },
  error: { fontSize: 12, fontFamily: 'Inter_500Medium', marginTop: 10 },
  resend: { textAlign: 'center', fontSize: 12, fontFamily: 'Inter_700Bold', marginTop: 19 },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 25 },
  footerText: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  link: { fontSize: 12, fontFamily: 'Inter_700Bold' },
});