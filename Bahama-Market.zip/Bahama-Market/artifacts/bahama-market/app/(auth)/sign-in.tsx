import * as AuthSession from 'expo-auth-session';
import * as WebBrowser from 'expo-web-browser';
import { useSSO, useSignIn } from '@clerk/clerk-expo';
import { Link, useRouter } from 'expo-router';
import React, { useCallback, useEffect, useState } from 'react';
import { Alert, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { LogoMark, PrimaryButton } from '@/components/MarketUI';
import { useColors } from '@/hooks/useColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

WebBrowser.maybeCompleteAuthSession();

function getErrorMessage(error: unknown) {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === 'object' && error !== null && 'message' in error && typeof error.message === 'string') return error.message;
  return 'Sign-in failed. Please check your details and try again.';
}

export default function SignInScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { isLoaded, signIn, setActive } = useSignIn();
  const { startSSOFlow } = useSSO();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [googleLoading, setGoogleLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const fetchStatus = isSubmitting || !isLoaded ? 'fetching' : 'idle';
  const errors = { fields: { identifier: authError ? { message: authError } : undefined } };
  const signInWithGoogle = useCallback(async () => {
    setGoogleLoading(true);
    try {
      const { createdSessionId, setActive } = await startSSOFlow({ strategy: 'oauth_google', redirectUrl: AuthSession.makeRedirectUri({ scheme: 'bahama-market' }) });
      if (createdSessionId && setActive) { await setActive({ session: createdSessionId }); router.replace('/'); }
    } catch { Alert.alert('Could not connect', 'Please try again or use email and password.'); } finally { setGoogleLoading(false); }
  }, [router, startSSOFlow]);
  const submit = async () => {
    if (!isLoaded || !signIn || !setActive) return;
    setIsSubmitting(true);
    setAuthError(null);
    try {
      const result = await signIn.create({ identifier: email.trim(), password });
      if (result.status === 'complete' && result.createdSessionId) {
        await setActive({ session: result.createdSessionId });
        router.replace('/');
      } else {
        setAuthError('Additional verification is required to finish signing in.');
      }
    } catch (error) {
      setAuthError(getErrorMessage(error));
    } finally {
      setIsSubmitting(false);
    }
  };
  return <KeyboardAwareScrollViewCompat style={[styles.container, { backgroundColor: colors.background }]} contentContainerStyle={{ paddingTop: insets.top + 25, paddingHorizontal: 23, paddingBottom: insets.bottom + 25 }} bottomOffset={25} keyboardShouldPersistTaps="handled">
    <Pressable onPress={() => router.back()} style={styles.close}><Text style={[styles.closeText, { color: colors.mutedForeground }]}>Close</Text></Pressable><LogoMark /><Text style={[styles.title, { color: colors.foreground }]}>Welcome back.</Text><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Your local marketplace is waiting.</Text>
    <><Pressable testID="google-sign-in" onPress={signInWithGoogle} style={({ pressed }) => [styles.googleButton, { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed || googleLoading ? 0.75 : 1 }]}><Text style={[styles.googleG, { color: colors.primary }]}>G</Text><Text style={[styles.googleText, { color: colors.foreground }]}>Continue with Google</Text></Pressable><View style={styles.divider}><View style={[styles.line, { backgroundColor: colors.border }]} /><Text style={[styles.or, { color: colors.mutedForeground }]}>or use email</Text><View style={[styles.line, { backgroundColor: colors.border }]} /></View><Text style={[styles.label, { color: colors.foreground }]}>Email address</Text><TextInput testID="sign-in-email" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} placeholder="you@example.com" placeholderTextColor={colors.mutedForeground} style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]} /><Text style={[styles.label, { color: colors.foreground }]}>Password</Text><TextInput testID="sign-in-password" secureTextEntry value={password} onChangeText={setPassword} placeholder="Your password" placeholderTextColor={colors.mutedForeground} style={[styles.input, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]} /><PrimaryButton label="Sign in" onPress={submit} disabled={!email || !password || fetchStatus === 'fetching'} />{errors.fields.identifier && <Text style={[styles.error, { color: colors.destructive }]}>{errors.fields.identifier.message}</Text>}</>
    <View style={styles.footer}><Text style={[styles.footerText, { color: colors.mutedForeground }]}>New to Bahama Market?</Text><Link href="/(auth)/sign-up" asChild><Pressable><Text style={[styles.link, { color: colors.primary }]}> Create an account</Text></Pressable></Link></View>
  </KeyboardAwareScrollViewCompat>;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  close: { alignSelf: 'flex-end', paddingVertical: 8, marginBottom: 22 },
  closeText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  title: { fontSize: 30, fontFamily: 'Inter_700Bold', letterSpacing: -1, marginTop: 41, marginBottom: 7 },
  subtitle: { fontSize: 14, fontFamily: 'Inter_400Regular', marginBottom: 28 },
  googleButton: { minHeight: 51, borderRadius: 15, borderWidth: 1, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9 },
  googleG: { fontSize: 17, fontFamily: 'Inter_700Bold' },
  googleText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  divider: { flexDirection: 'row', alignItems: 'center', gap: 9, marginVertical: 21 },
  line: { height: 1, flex: 1 },
  or: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  label: { fontSize: 12, fontFamily: 'Inter_700Bold', marginBottom: 8 },
  input: { minHeight: 51, borderRadius: 15, borderWidth: 1, paddingHorizontal: 14, fontSize: 14, fontFamily: 'Inter_500Medium', marginBottom: 17 },
  error: { fontSize: 12, fontFamily: 'Inter_500Medium', marginTop: 10 },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 25 },
  footerText: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  link: { fontSize: 12, fontFamily: 'Inter_700Bold' },
});