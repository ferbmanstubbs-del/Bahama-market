import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React from 'react';
import { FlatList, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Avatar, IconButton, ListingCard } from '@/components/MarketUI';
import { sellers } from '@/constants/market';
import { useColors } from '@/hooks/useColors';
import { useMarket } from '@/context/MarketContext';

export default function SellerProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { listings, favorites, toggleFavorite } = useMarket();
  const seller = sellers.find((item) => item.id === id) || listings.find((item) => item.seller.id === id)?.seller;
  const sellerListings = listings.filter((item) => item.seller.id === id);
  if (!seller) return <View style={[styles.missing, { backgroundColor: colors.background }]}><Text style={{ color: colors.foreground }}>Seller not found</Text></View>;
  return <View style={[styles.container, { backgroundColor: colors.background }]}><FlatList data={sellerListings} numColumns={2} keyExtractor={(item) => item.id} columnWrapperStyle={styles.column} contentContainerStyle={{ paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 15), paddingHorizontal: 17, paddingBottom: insets.bottom + 35 }} ListHeaderComponent={<View><View style={styles.nav}><IconButton icon="arrow-back" label="Go back" onPress={() => router.back()} /></View><View style={styles.profile}><Avatar seller={seller} size={76} /><Text style={[styles.name, { color: colors.foreground }]}>{seller.name}</Text><View style={styles.place}><Ionicons name="location-outline" size={13} color={colors.mutedForeground} /><Text style={[styles.placeText, { color: colors.mutedForeground }]}>{seller.location}</Text></View><View style={styles.trust}><View style={styles.trustItem}><Ionicons name="star" size={14} color={colors.accent} /><Text style={[styles.trustText, { color: colors.foreground }]}>{seller.rating}</Text></View><View style={styles.trustItem}><Ionicons name="checkmark-circle-outline" size={14} color={colors.primary} /><Text style={[styles.trustText, { color: colors.foreground }]}>{seller.sales}</Text></View></View></View><Text style={[styles.sectionTitle, { color: colors.foreground }]}>{sellerListings.length} listings</Text></View>} renderItem={({ item }) => <ListingCard listing={item} isFavorite={favorites.includes(item.id)} onFavorite={() => toggleFavorite(item.id)} onPress={() => router.push(`/listing/${item.id}`)} />} ListEmptyComponent={<Text style={[styles.empty, { color: colors.mutedForeground }]}>This seller has no other listings yet.</Text>} /></View>;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  nav: { marginBottom: 23 },
  profile: { alignItems: 'center', marginBottom: 30 },
  name: { fontSize: 23, fontFamily: 'Inter_700Bold', marginTop: 13, marginBottom: 6 },
  place: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  placeText: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  trust: { flexDirection: 'row', gap: 19, marginTop: 15 },
  trustItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  trustText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  sectionTitle: { fontSize: 17, fontFamily: 'Inter_700Bold', marginBottom: 14 },
  column: { gap: 12 },
  empty: { textAlign: 'center', paddingTop: 30, fontFamily: 'Inter_400Regular' },
  missing: { flex: 1, alignItems: 'center', justifyContent: 'center' },
});