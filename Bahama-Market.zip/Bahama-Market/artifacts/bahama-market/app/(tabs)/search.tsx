import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { FlatList, Platform, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CategoryChip, ListingCard } from '@/components/MarketUI';
import { Category } from '@/constants/market';
import { useColors } from '@/hooks/useColors';
import { useMarket } from '@/context/MarketContext';

const categories: { label: Category; icon: keyof typeof Ionicons.glyphMap }[] = [
  { label: 'All', icon: 'grid-outline' }, { label: 'Vehicles', icon: 'car-outline' }, { label: 'Home', icon: 'home-outline' },
  { label: 'Fashion', icon: 'shirt-outline' }, { label: 'Electronics', icon: 'phone-portrait-outline' }, { label: 'Services', icon: 'sparkles-outline' },
];

export default function SearchScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { listings, favorites, toggleFavorite } = useMarket();
  const [query, setQuery] = React.useState('');
  const [category, setCategory] = React.useState<Category>('All');
  const filtered = listings.filter((item) => {
    const matchesCategory = category === 'All' || item.category === category;
    const normalized = query.toLowerCase().trim();
    return matchesCategory && (!normalized || `${item.title} ${item.location} ${item.category}`.toLowerCase().includes(normalized));
  });
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={filtered}
        numColumns={2}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 14), paddingHorizontal: 17, paddingBottom: insets.bottom + 96 }}
        columnWrapperStyle={styles.column}
        showsVerticalScrollIndicator={false}
         ListHeaderComponent={<View><Text style={[styles.title, { color: colors.foreground }]}>Search</Text><View style={[styles.inputWrap, { backgroundColor: colors.card, borderColor: colors.border }]}><Ionicons name="search" size={20} color={colors.primary} /><TextInput testID="search-input" value={query} onChangeText={setQuery} autoFocus placeholder="What are you looking for?" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground }]} /><Ionicons name="options-outline" size={19} color={colors.mutedForeground} /></View><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>{categories.map((item) => <CategoryChip key={item.label} label={item.label} icon={item.icon} selected={category === item.label} onPress={() => setCategory(item.label)} />)}</ScrollView><Text style={[styles.results, { color: colors.mutedForeground }]}>{filtered.length} {filtered.length === 1 ? 'result' : 'results'} near Nassau</Text></View>}
        renderItem={({ item }) => <ListingCard listing={item} isFavorite={favorites.includes(item.id)} onFavorite={() => toggleFavorite(item.id)} onPress={() => router.push(`/listing/${item.id}`)} />}
        ListEmptyComponent={<View style={styles.empty}><Ionicons name="search-outline" size={34} color={colors.primary} /><Text style={[styles.emptyTitle, { color: colors.foreground }]}>Nothing matched that search</Text><Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>Try a broader search or another category.</Text></View>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { fontSize: 29, fontFamily: 'Inter_700Bold', letterSpacing: -0.8, marginBottom: 18 },
  inputWrap: { height: 53, borderRadius: 16, borderWidth: 1, paddingHorizontal: 15, alignItems: 'center', flexDirection: 'row', gap: 10, marginBottom: 16 },
  input: { flex: 1, fontSize: 14, fontFamily: 'Inter_500Medium' },
  chips: { gap: 8, paddingBottom: 21 },
  results: { fontSize: 12, fontFamily: 'Inter_500Medium', marginBottom: 15 },
  column: { gap: 12 },
  empty: { alignItems: 'center', paddingTop: 78, paddingHorizontal: 30 },
  emptyTitle: { fontSize: 17, fontFamily: 'Inter_700Bold', marginTop: 14, marginBottom: 7 },
  emptyCopy: { textAlign: 'center', fontSize: 13, fontFamily: 'Inter_400Regular' },
});