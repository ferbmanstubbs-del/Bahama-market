import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { Alert, Image, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@clerk/clerk-expo';
import { AuthPrompt, CategoryChip, PrimaryButton } from '@/components/MarketUI';
import { Category } from '@/constants/market';
import { useColors } from '@/hooks/useColors';
import { useMarket } from '@/context/MarketContext';

const categories: { label: Exclude<Category, 'All'>; icon: keyof typeof Ionicons.glyphMap }[] = [
  { label: 'Vehicles', icon: 'car-outline' }, { label: 'Home', icon: 'home-outline' }, { label: 'Fashion', icon: 'shirt-outline' }, { label: 'Electronics', icon: 'phone-portrait-outline' }, { label: 'Services', icon: 'sparkles-outline' },
];

export default function SellScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { isSignedIn } = useAuth();
  const { addListing } = useMarket();
  const [title, setTitle] = React.useState('');
  const [price, setPrice] = React.useState('');
  const [location, setLocation] = React.useState('Nassau, NP');
  const [description, setDescription] = React.useState('');
  const [image, setImage] = React.useState<{ uri: string } | null>(null);
  const [category, setCategory] = React.useState<Exclude<Category, 'All'>>('Home');
  const [condition, setCondition] = React.useState('Good');
  const [locating, setLocating] = React.useState(false);
  const [submitted, setSubmitted] = React.useState(false);

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, quality: 0.85 });
    if (!result.canceled && result.assets[0]) setImage({ uri: result.assets[0].uri });
  };
  const useLocation = async () => {
    if (Platform.OS === 'web') { setLocation('Nassau, NP'); return; }
    setLocating(true);
    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (!permission.granted) { Alert.alert('Location access', 'You can still enter your location manually.'); return; }
      const current = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const address = await Location.reverseGeocodeAsync(current.coords);
      const first = address[0];
      setLocation([first?.district, first?.city, first?.region].filter(Boolean).join(', ') || 'Nassau, NP');
    } catch { Alert.alert('Location unavailable', 'Enter your location manually instead.'); }
    finally { setLocating(false); }
  };
  const publish = () => {
    if (!title.trim() || !price || !location.trim() || !image) { Alert.alert('Almost there', 'Add a photo, title, price, and location to publish.'); return; }
    addListing({ title: title.trim(), price: Number(price.replace(/[^0-9.]/g, '')), location: location.trim(), category, condition, description: description.trim() || 'Message me for more details.', image });
    setSubmitted(true);
  };

  if (!isSignedIn) return <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top + 25, paddingHorizontal: 17 }]}><Text style={[styles.title, { color: colors.foreground }]}>Sell on Bahama Market</Text><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Turn the things you are not using into extra BSD.</Text><AuthPrompt onPress={() => router.push('/(auth)/sign-in')} /></View>;
  if (submitted) return <View style={[styles.success, { backgroundColor: colors.background, paddingTop: insets.top + 75 }]}><View style={[styles.successIcon, { backgroundColor: colors.secondary }]}><Ionicons name="checkmark" size={36} color={colors.primary} /></View><Text style={[styles.successTitle, { color: colors.foreground }]}>Your listing is live.</Text><Text style={[styles.successCopy, { color: colors.mutedForeground }]}>Your item is now visible to buyers around The Bahamas.</Text><PrimaryButton label="Back to home" onPress={() => { setSubmitted(false); router.replace('/'); }} /></View>;

  return <KeyboardAwareScrollViewCompat style={[styles.container, { backgroundColor: colors.background }]} contentContainerStyle={{ paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 15), paddingHorizontal: 17, paddingBottom: insets.bottom + 100 }} bottomOffset={25} keyboardShouldPersistTaps="handled">
    <Text style={[styles.title, { color: colors.foreground }]}>List an item</Text><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>A clear photo and honest details help it find a new home.</Text>
    <Pressable testID="add-photo" onPress={pickImage} style={[styles.photoPicker, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
      {image ? <Image source={image} style={styles.previewImage} /> : <><View style={[styles.photoIcon, { backgroundColor: colors.card }]}><Ionicons name="camera-outline" size={26} color={colors.primary} /></View><Text style={[styles.photoTitle, { color: colors.foreground }]}>Add photos</Text><Text style={[styles.photoHint, { color: colors.mutedForeground }]}>Tap to choose from your gallery</Text></>}
    </Pressable>
    <Text style={[styles.label, { color: colors.foreground }]}>What are you selling?</Text><TextInput testID="listing-title" value={title} onChangeText={setTitle} placeholder="e.g. Solid wood dining table" placeholderTextColor={colors.mutedForeground} style={[styles.field, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]} />
    <View style={styles.row}><View style={styles.half}><Text style={[styles.label, { color: colors.foreground }]}>Price</Text><View style={[styles.priceField, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.currencyLabel, { color: colors.mutedForeground }]}>$</Text><TextInput testID="listing-price" value={price} onChangeText={setPrice} placeholder="0.00" keyboardType="decimal-pad" placeholderTextColor={colors.mutedForeground} style={[styles.priceInput, { color: colors.foreground }]} /><Text style={[styles.currencyLabel, { color: colors.mutedForeground }]}>BSD</Text></View></View><View style={styles.half}><Text style={[styles.label, { color: colors.foreground }]}>Condition</Text><View style={[styles.conditionWrap, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.conditionText, { color: colors.foreground }]}>{condition}</Text><Ionicons name="chevron-down" size={15} color={colors.mutedForeground} /></View></View></View>
    <Text style={[styles.label, { color: colors.foreground }]}>Category</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryRow}>{categories.map((item) => <CategoryChip key={item.label} label={item.label} icon={item.icon} selected={category === item.label} onPress={() => setCategory(item.label)} />)}</ScrollView>
    <Text style={[styles.label, { color: colors.foreground }]}>Location</Text><View style={styles.locationInputRow}><TextInput testID="listing-location" value={location} onChangeText={setLocation} placeholder="Nassau, NP" placeholderTextColor={colors.mutedForeground} style={[styles.field, styles.locationField, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]} /><Pressable testID="use-location" onPress={useLocation} style={[styles.locationButton, { backgroundColor: colors.secondary }]}><Ionicons name="navigate-outline" size={18} color={colors.primary} /></Pressable></View>{locating && <Text style={[styles.locating, { color: colors.mutedForeground }]}>Finding your location…</Text>}
    <Text style={[styles.label, { color: colors.foreground }]}>Description <Text style={[styles.optional, { color: colors.mutedForeground }]}>optional</Text></Text><TextInput testID="listing-description" value={description} onChangeText={setDescription} multiline numberOfLines={4} placeholder="Tell buyers a little more…" placeholderTextColor={colors.mutedForeground} style={[styles.field, styles.description, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]} />
    <PrimaryButton label="Publish listing" icon="arrow-up-circle-outline" onPress={publish} />
  </KeyboardAwareScrollViewCompat>;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { fontSize: 29, fontFamily: 'Inter_700Bold', letterSpacing: -0.8, marginBottom: 7 },
  subtitle: { fontSize: 13, fontFamily: 'Inter_400Regular', lineHeight: 20, marginBottom: 21 },
  photoPicker: { height: 180, borderRadius: 20, borderWidth: 1, borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', marginBottom: 24, overflow: 'hidden' },
  previewImage: { width: '100%', height: '100%' },
  photoIcon: { width: 53, height: 53, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  photoTitle: { fontSize: 14, fontFamily: 'Inter_700Bold', marginBottom: 5 },
  photoHint: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  label: { fontSize: 12, fontFamily: 'Inter_700Bold', marginBottom: 8 },
  field: { minHeight: 50, borderRadius: 14, borderWidth: 1, paddingHorizontal: 14, fontSize: 14, fontFamily: 'Inter_500Medium', marginBottom: 17 },
  row: { flexDirection: 'row', gap: 11 },
  half: { flex: 1 },
  priceField: { minHeight: 50, borderRadius: 14, borderWidth: 1, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13, marginBottom: 17 },
  currencyLabel: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  priceInput: { flex: 1, fontSize: 14, fontFamily: 'Inter_500Medium', paddingHorizontal: 7 },
  conditionWrap: { minHeight: 50, borderRadius: 14, borderWidth: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 13, marginBottom: 17 },
  conditionText: { fontSize: 13, fontFamily: 'Inter_500Medium' },
  categoryRow: { gap: 8, paddingBottom: 19 },
  locationInputRow: { flexDirection: 'row', gap: 8 },
  locationField: { flex: 1 },
  locationButton: { height: 50, width: 50, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  locating: { fontSize: 11, marginTop: -10, marginBottom: 12, fontFamily: 'Inter_400Regular' },
  optional: { fontFamily: 'Inter_400Regular' },
  description: { minHeight: 100, paddingTop: 14, textAlignVertical: 'top', marginBottom: 23 },
  success: { flex: 1, alignItems: 'center', paddingHorizontal: 32 },
  successIcon: { width: 82, height: 82, borderRadius: 29, alignItems: 'center', justifyContent: 'center', marginBottom: 22 },
  successTitle: { fontSize: 24, fontFamily: 'Inter_700Bold', marginBottom: 9 },
  successCopy: { fontSize: 14, lineHeight: 21, fontFamily: 'Inter_400Regular', textAlign: 'center', marginBottom: 26 },
});