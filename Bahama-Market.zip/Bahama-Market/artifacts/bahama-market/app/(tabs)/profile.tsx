import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { FlatList, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth, useClerk, useUser } from '@clerk/clerk-expo';
import { Avatar, AuthPrompt, EmptyState, ListingCard } from '@/components/MarketUI';
import { useColors } from '@/hooks/useColors';
import { useMarket } from '@/context/MarketContext';

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { isSignedIn } = useAuth();
  const { user } = useUser();
  const { signOut } = useClerk();
  const { listings, favorites, toggleFavorite } = useMarket();
  const savedListings = listings.filter((listing) => favorites.includes(listing.id));
  const seller = { id: 'me', name: user?.fullName || 'Your profile', initials: (user?.firstName?.[0] || 'Y') + (user?.lastName?.[0] || 'M'), location: 'Nassau, NP', rating: 'New', sales: '0 sales', color: colors.accent };
  if (!isSignedIn) return <View style={[styles.container, { backgroundColor: colors.background, paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 25), paddingHorizontal: 17 }]}><Text style={[styles.title, { color: colors.foreground }]}>Your profile</Text><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>A place for your listings, saved finds, and seller identity.</Text><AuthPrompt onPress={() => router.push('/(auth)/sign-in')} /><View style={[styles.guestCard, { backgroundColor: colors.card, borderColor: colors.border }]}><Ionicons name="shield-checkmark-outline" size={22} color={colors.primary} /><Text style={[styles.guestTitle, { color: colors.foreground }]}>Built for local trust</Text><Text style={[styles.guestCopy, { color: colors.mutedForeground }]}>Meet nearby sellers, ask questions, and make the exchange feel easy.</Text></View></View>;
  return <FlatList data={savedListings} numColumns={2} keyExtractor={(item) => item.id} columnWrapperStyle={styles.column} contentContainerStyle={{ paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 15), paddingHorizontal: 17, paddingBottom: insets.bottom + 95 }} ListHeaderComponent={<View><View style={styles.topRow}><Text style={[styles.title, { color: colors.foreground }]}>Profile</Text><Pressable testID="sign-out" onPress={() => signOut()}><Text style={[styles.signOut, { color: colors.primary }]}>Sign out</Text></Pressable></View><View style={[styles.profileCard, { backgroundColor: colors.card, borderColor: colors.border }]}><Avatar seller={seller} size={63} /><View style={styles.profileCopy}><Text style={[styles.profileName, { color: colors.foreground }]}>{seller.name}</Text><View style={styles.profileMeta}><Ionicons name="location-outline" size={13} color={colors.mutedForeground} /><Text style={[styles.metaText, { color: colors.mutedForeground }]}>Nassau, The Bahamas</Text></View></View><Pressable><Ionicons name="settings-outline" size={20} color={colors.mutedForeground} /></Pressable></View><View style={styles.stats}><View><Text style={[styles.statValue, { color: colors.foreground }]}>{listings.filter((item) => item.seller.id === 'me').length}</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>Listings</Text></View><View><Text style={[styles.statValue, { color: colors.foreground }]}>{savedListings.length}</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>Saved</Text></View><View><Text style={[styles.statValue, { color: colors.foreground }]}>New</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>Seller status</Text></View></View><View style={[styles.tabs, { borderBottomColor: colors.border }]}><View style={[styles.tab, { borderBottomColor: colors.primary }]}><Text style={[styles.tabText, { color: colors.foreground }]}>Saved finds</Text></View><View style={styles.tab}><Text style={[styles.tabText, { color: colors.mutedForeground }]}>My listings</Text></View></View></View>} renderItem={({ item }) => <ListingCard listing={item} isFavorite onFavorite={() => toggleFavorite(item.id)} onPress={() => router.push(`/listing/${item.id}`)} />} ListEmptyComponent={<EmptyState icon="heart-outline" title="Your saved finds live here" message="Tap the heart on a listing to keep it close." />} />;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { fontSize: 29, fontFamily: 'Inter_700Bold', letterSpacing: -0.8, marginBottom: 7 },
  subtitle: { fontSize: 13, lineHeight: 20, fontFamily: 'Inter_400Regular', marginBottom: 21 },
  guestCard: { borderRadius: 18, borderWidth: 1, padding: 18, marginTop: 20 },
  guestTitle: { fontSize: 14, fontFamily: 'Inter_700Bold', marginTop: 13, marginBottom: 5 },
  guestCopy: { fontSize: 12, lineHeight: 18, fontFamily: 'Inter_400Regular' },
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  signOut: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  profileCard: { borderRadius: 20, borderWidth: 1, padding: 15, flexDirection: 'row', alignItems: 'center', gap: 13, marginTop: 13 },
  profileCopy: { flex: 1 },
  profileName: { fontSize: 17, fontFamily: 'Inter_700Bold', marginBottom: 5 },
  profileMeta: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  stats: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 21 },
  statValue: { textAlign: 'center', fontSize: 16, fontFamily: 'Inter_700Bold', marginBottom: 4 },
  statLabel: { textAlign: 'center', fontSize: 10, fontFamily: 'Inter_500Medium' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, marginBottom: 16 },
  tab: { flex: 1, alignItems: 'center', paddingBottom: 12, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  column: { gap: 12 },
});