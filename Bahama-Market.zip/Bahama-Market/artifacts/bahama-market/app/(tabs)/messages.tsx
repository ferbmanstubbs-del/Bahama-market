import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { FlatList, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@clerk/clerk-expo';
import { AuthPrompt, Avatar, EmptyState } from '@/components/MarketUI';
import { useColors } from '@/hooks/useColors';
import { useMarket } from '@/context/MarketContext';

export default function MessagesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { isSignedIn } = useAuth();
  const { conversations } = useMarket();
  return <View style={[styles.container, { backgroundColor: colors.background }]}><FlatList data={isSignedIn ? conversations : []} keyExtractor={(item) => item.id} contentContainerStyle={{ paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 15), paddingHorizontal: 17, paddingBottom: insets.bottom + 95, flexGrow: 1 }} ListHeaderComponent={<View><View style={styles.header}><View><Text style={[styles.title, { color: colors.foreground }]}>Messages</Text><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Keep conversations moving.</Text></View><Pressable style={[styles.compose, { backgroundColor: colors.secondary }]}><Ionicons name="create-outline" size={19} color={colors.primary} /></Pressable></View>{!isSignedIn && <AuthPrompt onPress={() => router.push('/(auth)/sign-in')} />}</View>} renderItem={({ item }) => <Pressable testID={`conversation-${item.id}`} onPress={() => router.push(`/message/${item.id}`)} style={({ pressed }) => [styles.row, { borderBottomColor: colors.border, opacity: pressed ? 0.72 : 1 }]}><Avatar seller={item.seller} size={49} /><View style={styles.rowCopy}><View style={styles.rowTitle}><Text numberOfLines={1} style={[styles.sellerName, { color: colors.foreground }]}>{item.seller.name}</Text><Text style={[styles.time, { color: colors.mutedForeground }]}>{item.timestamp}</Text></View><Text numberOfLines={1} style={[styles.listing, { color: colors.primary }]}>{item.listingTitle}</Text><Text numberOfLines={1} style={[styles.last, { color: colors.mutedForeground }]}>{item.lastMessage}</Text></View>{item.unread && <View style={[styles.dot, { backgroundColor: colors.accent }]} />}</Pressable>} ListEmptyComponent={isSignedIn ? <EmptyState icon="chatbubbles-outline" title="No conversations yet" message="When you message a seller, your conversation will appear here." /> : null} /></View>;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 21 },
  title: { fontSize: 29, fontFamily: 'Inter_700Bold', letterSpacing: -0.8, marginBottom: 6 },
  subtitle: { fontSize: 13, fontFamily: 'Inter_400Regular' },
  compose: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  row: { minHeight: 83, flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, gap: 12 },
  rowCopy: { flex: 1 },
  rowTitle: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  sellerName: { fontSize: 14, fontFamily: 'Inter_700Bold', flex: 1 },
  time: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  listing: { fontSize: 11, fontFamily: 'Inter_600SemiBold', marginBottom: 4 },
  last: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  dot: { width: 9, height: 9, borderRadius: 5, marginRight: 3 },
});