import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { FlatList, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth, useUser } from '@clerk/clerk-expo';
import { CategoryChip, IconButton, ListingCard, LogoMark, SearchBar, SectionTitle } from '@/components/MarketUI';
import { Category } from '@/constants/market';
import { useColors } from '@/hooks/useColors';
import { useMarket } from '@/context/MarketContext';

const categories: { label: Category; icon: keyof typeof Ionicons.glyphMap }[] = [
  { label: 'All', icon: 'grid-outline' }, { label: 'Vehicles', icon: 'car-outline' }, { label: 'Home', icon: 'home-outline' },
  { label: 'Fashion', icon: 'shirt-outline' }, { label: 'Electronics', icon: 'phone-portrait-outline' },
];

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { isSignedIn } = useAuth();
  const { user } = useUser();
  const { listings, favorites, toggleFavorite } = useMarket();
  const [category, setCategory] = React.useState<Category>('All');
  const topPadding = insets.top + (Platform.OS === 'web' ? 67 : 13);
  const filtered = category === 'All' ? listings : listings.filter((item) => item.category === category);
  const firstName = user?.firstName || 'there';

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={filtered.slice(0, 4)}
        numColumns={2}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingTop: topPadding, paddingHorizontal: 17, paddingBottom: insets.bottom + 98 }}
        columnWrapperStyle={styles.column}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View>
            <View style={styles.header}>
              <LogoMark />
              <View style={styles.headerActions}>
                {isSignedIn && <IconButton icon="person-circle-outline" label="Profile" onPress={() => router.push('/profile')} />}
                <IconButton icon="notifications-outline" label="Notifications" />
              </View>
            </View>
            {!isSignedIn && (
              <View style={styles.authActions}>
                <Pressable
                  testID="home-sign-in"
                  accessibilityRole="button"
                  accessibilityLabel="Sign in"
                  onPress={() => router.push('/(auth)/sign-in')}
                  style={({ pressed }) => [
                    styles.authAction,
                    { backgroundColor: colors.primary, borderColor: colors.primary, opacity: pressed ? 0.8 : 1 },
                  ]}
                >
                  <Text style={[styles.authActionText, { color: colors.primaryForeground }]}>Sign in</Text>
                </Pressable>
                <Pressable
                  testID="home-create-account"
                  accessibilityRole="button"
                  accessibilityLabel="Create account"
                  onPress={() => router.push('/(auth)/sign-up')}
                  style={({ pressed }) => [
                    styles.authAction,
                    { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.75 : 1 },
                  ]}
                >
                  <Text style={[styles.authActionText, { color: colors.foreground }]}>Create account</Text>
                </Pressable>
              </View>
            )}
            <Text style={[styles.eyebrow, { color: colors.primary }]}>GOOD MORNING, {firstName.toUpperCase()}</Text>
            <Text style={[styles.heading, { color: colors.foreground }]}>Find your next <Text style={{ color: colors.primary }}>good thing.</Text></Text>
            <Pressable onPress={() => router.push('/search')} style={styles.searchWrap}><SearchBar onPress={() => router.push('/search')} /></Pressable>
            <View style={styles.locationLine}><Ionicons name="location" size={14} color={colors.primary} /><Text style={[styles.locationText, { color: colors.mutedForeground }]}>Nassau, New Providence</Text><Ionicons name="chevron-down" size={14} color={colors.mutedForeground} /></View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
              {categories.map((item) => <CategoryChip key={item.label} label={item.label} icon={item.icon} selected={category === item.label} onPress={() => setCategory(item.label)} />)}
            </ScrollView>
            <SectionTitle title="Fresh near you" action="See all" onAction={() => router.push('/search')} />
          </View>
        }
        renderItem={({ item }) => <ListingCard listing={item} isFavorite={favorites.includes(item.id)} onFavorite={() => toggleFavorite(item.id)} onPress={() => router.push(`/listing/${item.id}`)} />}
        ListFooterComponent={
          <View style={styles.footerSections}>
            <SectionTitle title="Make space. Make BSD." />
            <Pressable onPress={() => router.push('/sell')} style={[styles.sellBanner, { backgroundColor: colors.primary }]}>
              <View style={styles.bannerCopy}><Text style={[styles.bannerKicker, { color: colors.accent }]}>READY TO LET GO?</Text><Text style={[styles.bannerTitle, { color: colors.primaryForeground }]}>Sell something you no longer need.</Text><Text style={[styles.bannerLink, { color: colors.primaryForeground }]}>List it in under a minute <Ionicons name="arrow-forward" size={15} /></Text></View>
              <Ionicons name="arrow-up-circle-outline" size={62} color={colors.primaryForeground} />
            </Pressable>
          </View>
        }
        ListEmptyComponent={<Text style={[styles.emptyText, { color: colors.mutedForeground }]}>No listings in this category yet.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 17 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  authActions: { flexDirection: 'row', gap: 9, marginBottom: 21 },
  authAction: { flex: 1, minHeight: 44, borderRadius: 14, borderWidth: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 9 },
  authActionText: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  eyebrow: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.1, marginBottom: 9 },
  heading: { fontSize: 29, lineHeight: 35, letterSpacing: -1.1, fontFamily: 'Inter_700Bold', maxWidth: 320, marginBottom: 20 },
  searchWrap: { marginBottom: 10 },
  locationLine: { flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 20 },
  locationText: { fontSize: 12, fontFamily: 'Inter_500Medium', flex: 0 },
  chips: { gap: 8, paddingBottom: 26 },
  column: { gap: 12 },
  footerSections: { marginTop: 15 },
  sellBanner: { borderRadius: 20, minHeight: 145, padding: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', overflow: 'hidden' },
  bannerCopy: { flex: 1, paddingRight: 12 },
  bannerKicker: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 1.1, marginBottom: 7 },
  bannerTitle: { fontSize: 17, lineHeight: 22, fontFamily: 'Inter_700Bold', marginBottom: 12 },
  bannerLink: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  emptyText: { paddingVertical: 50, textAlign: 'center', fontFamily: 'Inter_500Medium' },
});