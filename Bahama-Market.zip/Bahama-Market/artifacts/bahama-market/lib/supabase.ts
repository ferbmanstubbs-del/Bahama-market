import { createClient, SupabaseClient } from '@supabase/supabase-js';

function requiredConfig(value: string | undefined, name: string) {
  if (!value) throw new Error(`Missing ${name}. Configure Supabase before starting Bahama Market.`);
  return value;
}

const supabaseUrl = requiredConfig(process.env.EXPO_PUBLIC_SUPABASE_URL, 'EXPO_PUBLIC_SUPABASE_URL');
const supabaseAnonKey = requiredConfig(process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY, 'EXPO_PUBLIC_SUPABASE_ANON_KEY');

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type SupabaseAccessTokenGetter = () => Promise<string | null>;

export function createAuthenticatedSupabaseClient(getToken: SupabaseAccessTokenGetter): SupabaseClient {
  return createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
    },
    accessToken: getToken,
  });
}

export const LISTING_IMAGES_BUCKET = 'listing-images';

export async function uploadListingPhoto(
  client: SupabaseClient,
  localUri: string,
  ownerId: string,
  listingId: string,
): Promise<string> {
  if (/^https?:\/\//i.test(localUri)) return localUri;

  const response = await fetch(localUri);
  if (!response.ok) throw new Error('Unable to read the selected listing photo.');
  const blob = await response.blob();
  const extension = localUri.split('.').pop()?.split('?')[0]?.toLowerCase() || 'jpg';
  const path = `${ownerId}/${listingId}-${Date.now()}.${extension}`;
  const { error } = await client.storage.from(LISTING_IMAGES_BUCKET).upload(path, blob, {
    cacheControl: '31536000',
    contentType: blob.type || 'image/jpeg',
    upsert: true,
  });

  if (error) throw error;
  return client.storage.from(LISTING_IMAGES_BUCKET).getPublicUrl(path).data.publicUrl;
}