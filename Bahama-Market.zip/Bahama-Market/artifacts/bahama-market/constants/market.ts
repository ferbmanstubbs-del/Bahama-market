import { ImageSourcePropType } from 'react-native';

export type Category = 'All' | 'Vehicles' | 'Home' | 'Fashion' | 'Electronics' | 'Services';

export type Seller = {
  id: string;
  name: string;
  initials: string;
  location: string;
  rating: string;
  sales: string;
  color: string;
};

export type Listing = {
  id: string;
  title: string;
  price: number;
  location: string;
  category: Exclude<Category, 'All'>;
  condition: string;
  postedAt: string;
  description: string;
  image: ImageSourcePropType;
  seller: Seller;
  isNew?: boolean;
};

export type MarketMessage = {
  id: string;
  text: string;
  fromMe: boolean;
  time: string;
};

export type Conversation = {
  id: string;
  listingId?: string;
  buyerId?: string;
  seller: Seller;
  listingTitle: string;
  listingImage: ImageSourcePropType;
  lastMessage: string;
  timestamp: string;
  unread: boolean;
  messages: MarketMessage[];
};

export const sellers: Seller[] = [
  {
    id: 'marina',
    name: 'Marina Rolle',
    initials: 'MR',
    location: 'Nassau, NP',
    rating: '4.9',
    sales: '42 sales',
    color: '#F6B35D',
  },
  {
    id: 'jordan',
    name: 'Jordan Cooper',
    initials: 'JC',
    location: 'Cable Beach, NP',
    rating: '4.8',
    sales: '18 sales',
    color: '#8CC9BF',
  },
  {
    id: 'davian',
    name: 'Davian Moss',
    initials: 'DM',
    location: 'Eastern Road, NP',
    rating: '5.0',
    sales: '9 sales',
    color: '#F49A8C',
  },
];

export const seedListings: Listing[] = [
  {
    id: 'rattan-chair',
    title: 'Vintage rattan lounge chair',
    price: 185,
    location: 'Old Fort Bay',
    category: 'Home',
    condition: 'Like new',
    postedAt: '2h ago',
    description: 'Beautiful woven lounge chair in excellent condition. Adds a warm island feel to any room.',
    image: require('../assets/images/listing-chair.jpg'),
    seller: sellers[0],
    isNew: true,
  },
  {
    id: 'city-scooter',
    title: '2022 City scooter',
    price: 2400,
    location: 'Cable Beach',
    category: 'Vehicles',
    condition: 'Good',
    postedAt: '4h ago',
    description: 'Reliable city scooter, lightly used and ready for daily runs around Nassau.',
    image: require('../assets/images/listing-scooter.jpg'),
    seller: sellers[1],
    isNew: true,
  },
  {
    id: 'linen-sofa',
    title: 'Cream linen sofa',
    price: 850,
    location: 'Eastern Road',
    category: 'Home',
    condition: 'Good',
    postedAt: '1d ago',
    description: 'Soft cream linen sofa with lots of life left. Pickup from Eastern Road.',
    image: require('../assets/images/listing-sofa.jpg'),
    seller: sellers[2],
  },
  {
    id: 'island-camera',
    title: 'Fujifilm X-T30 camera',
    price: 1100,
    location: 'Downtown Nassau',
    category: 'Electronics',
    condition: 'Like new',
    postedAt: '1d ago',
    description: 'Compact mirrorless camera with a clean sensor and one battery. Great for island days.',
    image: { uri: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=900&q=80' },
    seller: sellers[0],
  },
  {
    id: 'linen-set',
    title: 'Island linen two-piece',
    price: 75,
    location: 'Winton Meadows',
    category: 'Fashion',
    condition: 'New',
    postedAt: '2d ago',
    description: 'Easy linen set in a soft sand tone. Never worn, size medium.',
    image: { uri: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=900&q=80' },
    seller: sellers[1],
  },
  {
    id: 'moving-help',
    title: 'Careful moving help',
    price: 60,
    location: 'Nassau, NP',
    category: 'Services',
    condition: 'Available',
    postedAt: '2d ago',
    description: 'Two-person moving help for apartments and small homes. Careful, punctual, and local.',
    image: { uri: 'https://images.unsplash.com/photo-1600518464441-9154a4dea21b?w=900&q=80' },
    seller: sellers[2],
  },
];

export const seedConversations: Conversation[] = [
  {
    id: 'conversation-marina',
    seller: sellers[0],
    listingTitle: 'Vintage rattan lounge chair',
    listingImage: seedListings[0].image,
    lastMessage: 'Yes, it is still available.',
    timestamp: '10:42 AM',
    unread: true,
    messages: [
      { id: 'm1', text: 'Hi! Is the rattan chair still available?', fromMe: true, time: '10:40 AM' },
      { id: 'm2', text: 'Yes, it is still available.', fromMe: false, time: '10:42 AM' },
    ],
  },
  {
    id: 'conversation-jordan',
    seller: sellers[1],
    listingTitle: '2022 City scooter',
    listingImage: seedListings[1].image,
    lastMessage: 'I can meet near Cable Beach.',
    timestamp: 'Yesterday',
    unread: false,
    messages: [
      { id: 'm3', text: 'I can meet near Cable Beach.', fromMe: false, time: 'Yesterday' },
    ],
  },
];