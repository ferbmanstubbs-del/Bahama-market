/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#11292D',
    tint: '#0D8B84',
    background: '#F7F8F5',
    foreground: '#11292D',
    card: '#FFFFFF',
    cardForeground: '#11292D',
    primary: '#0D8B84',
    primaryForeground: '#FFFFFF',
    secondary: '#E8F2EF',
    secondaryForeground: '#0D5A57',
    muted: '#EEF1ED',
    mutedForeground: '#6F7E7A',
    accent: '#F6B35D',
    accentForeground: '#533719',
    destructive: '#C94C45',
    destructiveForeground: '#FFFFFF',
    border: '#DDE5E0',
    input: '#E4EBE7',
  },
  dark: {
    text: '#F3F6F1',
    tint: '#55C4B5',
    background: '#102426',
    foreground: '#F3F6F1',
    card: '#183234',
    cardForeground: '#F3F6F1',
    primary: '#55C4B5',
    primaryForeground: '#102426',
    secondary: '#234441',
    secondaryForeground: '#D6F2EB',
    muted: '#21383A',
    mutedForeground: '#A5B8B3',
    accent: '#F6B35D',
    accentForeground: '#533719',
    destructive: '#E17168',
    destructiveForeground: '#FFFFFF',
    border: '#2B4848',
    input: '#2A4444',
  },
  radius: 16,
};

export default colors;
