import { Feather, Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { Image, ImageSourcePropType, Pressable, StyleSheet, Text, View } from 'react-native';
import { Listing, Seller } from '@/constants/market';
import { useColors } from '@/hooks/useColors';

export function LogoMark({ compact = false }: { compact?: boolean }) {
  const colors = useColors();
  return (
    <View style={styles.logoRow}>
      <View style={[styles.logoMark, { backgroundColor: colors.primary }]}>
        <Ionicons name="sunny" size={compact ? 16 : 19} color={colors.primaryForeground} />
      </View>
      {!compact && <Text style={[styles.logoText, { color: colors.foreground }]}>bahama <Text style={{ color: colors.primary }}>market</Text></Text>}
    </View>
  );
}

export function Avatar({ seller, size = 44 }: { seller: Seller; size?: number }) {
  const colors = useColors();
  return (
    <View style={[styles.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: seller.color || colors.secondary }]}>
      <Text style={[styles.avatarText, { fontSize: size * 0.31, color: colors.foreground }]}>{seller.initials}</Text>
    </View>
  );
}

export function IconButton({ icon, onPress, active = false, label }: { icon: keyof typeof Ionicons.glyphMap; onPress?: () => void; active?: boolean; label?: string }) {
  const colors = useColors();
  return (
    <Pressable testID={label} accessibilityLabel={label} onPress={onPress} style={({ pressed }) => [styles.iconButton, { backgroundColor: active ? colors.primary : colors.card, borderColor: active ? colors.primary : colors.border, opacity: pressed ? 0.7 : 1 }]}>
      <Ionicons name={icon} size={19} color={active ? colors.primaryForeground : colors.foreground} />
    </Pressable>
  );
}

export function SearchBar({ value, onChangeText, onPress, placeholder = 'Search for anything' }: { value?: string; onChangeText?: (value: string) => void; onPress?: () => void; placeholder?: string }) {
  const colors = useColors();
  const input = <View style={[styles.searchBar, { backgroundColor: colors.card, borderColor: colors.border }]}>
    <Ionicons name="search" size={19} color={colors.mutedForeground} />
    <Text style={[styles.searchPlaceholder, { color: value ? colors.foreground : colors.mutedForeground }]}>{value || placeholder}</Text>
    <Feather name="sliders" size={18} color={colors.mutedForeground} />
  </View>;
  return onPress ? <Pressable testID="search-button" onPress={onPress}>{input}</Pressable> : input;
}

export function CategoryChip({ label, icon, selected, onPress }: { label: string; icon: keyof typeof Ionicons.glyphMap; selected?: boolean; onPress?: () => void }) {
  const colors = useColors();
  return (
    <Pressable testID={`category-${label}`} onPress={onPress} style={({ pressed }) => [styles.categoryChip, { backgroundColor: selected ? colors.primary : colors.card, borderColor: selected ? colors.primary : colors.border, opacity: pressed ? 0.75 : 1 }]}>
      <Ionicons name={icon} size={17} color={selected ? colors.primaryForeground : colors.primary} />
      <Text style={[styles.categoryText, { color: selected ? colors.primaryForeground : colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

export function ListingCard({ listing, onPress, onFavorite, isFavorite, compact = false }: { listing: Listing; onPress: () => void; onFavorite: () => void; isFavorite: boolean; compact?: boolean }) {
  const colors = useColors();
  return (
    <Pressable testID={`listing-${listing.id}`} onPress={onPress} style={({ pressed }) => [compact ? styles.compactCard : styles.listingCard, { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.9 : 1 }]}>
      <View style={compact ? styles.compactImageWrap : styles.cardImageWrap}>
        <Image source={listing.image} style={styles.cardImage} />
        {listing.isNew && <View style={[styles.newBadge, { backgroundColor: colors.accent }]}><Text style={[styles.newBadgeText, { color: colors.accentForeground }]}>NEW</Text></View>}
        <Pressable testID={`favorite-${listing.id}`} accessibilityLabel="Save listing" onPress={onFavorite} style={styles.favoriteButton}>
          <Ionicons name={isFavorite ? 'heart' : 'heart-outline'} size={19} color={isFavorite ? colors.destructive : colors.foreground} />
        </Pressable>
      </View>
      <View style={styles.cardInfo}>
        <Text numberOfLines={1} style={[styles.listingTitle, { color: colors.foreground }]}>{listing.title}</Text>
        <Text style={[styles.price, { color: colors.foreground }]}>${listing.price.toLocaleString()} <Text style={[styles.currency, { color: colors.mutedForeground }]}>BSD</Text></Text>
        <View style={styles.metaRow}><Ionicons name="location-outline" size={13} color={colors.mutedForeground} /><Text numberOfLines={1} style={[styles.meta, { color: colors.mutedForeground }]}>{listing.location}</Text></View>
      </View>
    </Pressable>
  );
}

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const colors = useColors();
  return <View style={styles.sectionTitleRow}><Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>{action && <Pressable onPress={onAction}><Text style={[styles.seeAll, { color: colors.primary }]}>{action}</Text></Pressable>}</View>;
}

export function PrimaryButton({ label, onPress, icon, disabled = false }: { label: string; onPress: () => void; icon?: keyof typeof Ionicons.glyphMap; disabled?: boolean }) {
  const colors = useColors();
  return <Pressable testID={label} onPress={onPress} disabled={disabled} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: disabled ? 0.45 : pressed ? 0.8 : 1 }]}>{icon && <Ionicons name={icon} size={18} color={colors.primaryForeground} />}<Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>{label}</Text></Pressable>;
}

export function EmptyState({ icon, title, message }: { icon: keyof typeof Ionicons.glyphMap; title: string; message: string }) {
  const colors = useColors();
  return <View style={styles.emptyState}><View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}><Ionicons name={icon} size={28} color={colors.primary} /></View><Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text><Text style={[styles.emptyMessage, { color: colors.mutedForeground }]}>{message}</Text></View>;
}

export function AuthPrompt({ onPress }: { onPress: () => void }) {
  const colors = useColors();
  const router = useRouter();
  return (
    <View style={[styles.authPrompt, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
      <View style={styles.authPromptHeader}>
        <View style={[styles.authIcon, { backgroundColor: colors.card }]}>
          <Ionicons name="person-outline" size={23} color={colors.primary} />
        </View>
        <View style={styles.authCopy}>
          <Text style={[styles.authTitle, { color: colors.foreground }]}>Welcome to Bahama Market</Text>
          <Text style={[styles.authMessage, { color: colors.mutedForeground }]}>Sign in or join to sell, save finds, and chat with sellers.</Text>
        </View>
      </View>
      <View style={styles.authActions}>
        <Pressable
          testID="sign-in-prompt"
          accessibilityRole="button"
          accessibilityLabel="Sign in"
          onPress={onPress}
          style={({ pressed }) => [
            styles.authAction,
            { backgroundColor: colors.primary, borderColor: colors.primary, opacity: pressed ? 0.8 : 1 },
          ]}
        >
          <Text style={[styles.authActionText, { color: colors.primaryForeground }]}>Sign in</Text>
        </Pressable>
        <Pressable
          testID="create-account-prompt"
          accessibilityRole="button"
          accessibilityLabel="Create account"
          onPress={() => router.push('/(auth)/sign-up')}
          style={({ pressed }) => [
            styles.authAction,
            { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.75 : 1 },
          ]}
        >
          <Text style={[styles.authActionText, { color: colors.foreground }]}>Create account</Text>
        </Pressable>
      </View>
    </View>
  );
}

export const styles = StyleSheet.create({
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  logoMark: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  logoText: { fontSize: 17, fontFamily: 'Inter_700Bold', letterSpacing: -0.5 },
  avatar: { alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontFamily: 'Inter_700Bold' },
  iconButton: { width: 39, height: 39, borderRadius: 13, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  searchBar: { minHeight: 50, borderRadius: 16, borderWidth: 1, paddingHorizontal: 15, flexDirection: 'row', alignItems: 'center', gap: 11 },
  searchPlaceholder: { flex: 1, fontSize: 14, fontFamily: 'Inter_500Medium' },
  categoryChip: { paddingHorizontal: 14, minHeight: 38, borderRadius: 13, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 7 },
  categoryText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  listingCard: { flex: 1, borderRadius: 18, borderWidth: 1, overflow: 'hidden', marginBottom: 14 },
  compactCard: { width: 192, borderRadius: 18, borderWidth: 1, overflow: 'hidden', marginRight: 12 },
  cardImageWrap: { height: 145, position: 'relative' },
  compactImageWrap: { height: 142, position: 'relative' },
  cardImage: { width: '100%', height: '100%' },
  favoriteButton: { position: 'absolute', top: 9, right: 9, width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.9)', alignItems: 'center', justifyContent: 'center' },
  newBadge: { position: 'absolute', left: 9, top: 9, borderRadius: 7, paddingHorizontal: 7, paddingVertical: 4 },
  newBadgeText: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.6 },
  cardInfo: { padding: 12 },
  listingTitle: { fontSize: 13, fontFamily: 'Inter_600SemiBold', marginBottom: 7 },
  price: { fontSize: 16, fontFamily: 'Inter_700Bold', marginBottom: 6 },
  currency: { fontSize: 10, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.4 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  meta: { fontSize: 11, fontFamily: 'Inter_400Regular', flex: 1 },
  sectionTitleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 13 },
  sectionTitle: { fontSize: 18, fontFamily: 'Inter_700Bold', letterSpacing: -0.3 },
  seeAll: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  primaryButton: { height: 52, borderRadius: 16, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8, paddingHorizontal: 22 },
  primaryButtonText: { fontSize: 14, fontFamily: 'Inter_700Bold' },
  emptyState: { alignItems: 'center', justifyContent: 'center', paddingVertical: 58, paddingHorizontal: 30 },
  emptyIcon: { width: 64, height: 64, borderRadius: 22, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  emptyTitle: { fontSize: 17, fontFamily: 'Inter_700Bold', marginBottom: 7 },
  emptyMessage: { fontSize: 13, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 20 },
  authPrompt: { borderRadius: 18, borderWidth: 1, padding: 14, gap: 13 },
  authPromptHeader: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  authIcon: { width: 43, height: 43, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  authCopy: { flex: 1 },
  authTitle: { fontSize: 13, fontFamily: 'Inter_700Bold', marginBottom: 3 },
  authMessage: { fontSize: 11, fontFamily: 'Inter_400Regular', lineHeight: 16 },
  authActions: { flexDirection: 'row', gap: 9 },
  authAction: { minHeight: 43, flex: 1, borderRadius: 13, borderWidth: 1, paddingHorizontal: 8, alignItems: 'center', justifyContent: 'center' },
  authActionText: { fontSize: 12, fontFamily: 'Inter_700Bold' },
});