-- Bahama Market Supabase schema.
-- Clerk remains the identity provider. Configure a Clerk JWT template named
-- "supabase" and add Clerk as a trusted third-party auth provider in Supabase
-- so auth.jwt()->>'sub' resolves to the Clerk user id used below.

create or replace function public.current_clerk_user_id()
returns text
language sql
stable
as $$
  select coalesce(auth.jwt() ->> 'sub', '');
$$;

create table if not exists public.profiles (
  id text primary key,
  display_name text not null default 'Bahama Market member',
  initials text not null default 'BM',
  location text not null default 'The Bahamas',
  avatar_url text,
  color text not null default '#8CC9BF',
  rating text not null default 'New',
  sales text not null default '0 sales',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.listings (
  id text primary key,
  seller_id text not null references public.profiles(id) on delete cascade,
  title text not null,
  price numeric(12, 2) not null check (price >= 0),
  location text not null,
  category text not null check (category in ('Vehicles', 'Home', 'Fashion', 'Electronics', 'Services')),
  condition text not null,
  description text not null,
  image_url text,
  is_new boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.favorites (
  user_id text not null references public.profiles(id) on delete cascade,
  listing_id text not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, listing_id)
);

create table if not exists public.conversations (
  id text primary key,
  listing_id text not null references public.listings(id) on delete cascade,
  buyer_id text not null references public.profiles(id) on delete cascade,
  seller_id text not null references public.profiles(id) on delete cascade,
  last_message text not null default 'Start the conversation',
  unread boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.messages (
  id text primary key,
  conversation_id text not null references public.conversations(id) on delete cascade,
  sender_id text not null references public.profiles(id) on delete cascade,
  text text not null,
  created_at timestamptz not null default now()
);

create index if not exists listings_created_at_idx on public.listings (created_at desc);
create index if not exists conversations_buyer_id_idx on public.conversations (buyer_id);
create index if not exists conversations_seller_id_idx on public.conversations (seller_id);
create index if not exists messages_conversation_id_idx on public.messages (conversation_id, created_at);

do $$
begin
  alter publication supabase_realtime add table public.listings, public.favorites, public.conversations, public.messages;
exception
  when duplicate_object then null;
end $$;

alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.favorites enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;

drop policy if exists "Public profiles are readable" on public.profiles;
create policy "Public profiles are readable" on public.profiles for select using (true);
drop policy if exists "Users manage their profile" on public.profiles;
create policy "Users manage their profile" on public.profiles for all using (id = public.current_clerk_user_id()) with check (id = public.current_clerk_user_id());

drop policy if exists "Listings are publicly readable" on public.listings;
create policy "Listings are publicly readable" on public.listings for select using (true);
drop policy if exists "Users create their listings" on public.listings;
create policy "Users create their listings" on public.listings for insert with check (seller_id = public.current_clerk_user_id());
drop policy if exists "Users edit their listings" on public.listings;
create policy "Users edit their listings" on public.listings for update using (seller_id = public.current_clerk_user_id()) with check (seller_id = public.current_clerk_user_id());
drop policy if exists "Users delete their listings" on public.listings;
create policy "Users delete their listings" on public.listings for delete using (seller_id = public.current_clerk_user_id());

drop policy if exists "Users read their favorites" on public.favorites;
create policy "Users read their favorites" on public.favorites for select using (user_id = public.current_clerk_user_id());
drop policy if exists "Users manage their favorites" on public.favorites;
create policy "Users manage their favorites" on public.favorites for all using (user_id = public.current_clerk_user_id()) with check (user_id = public.current_clerk_user_id());

drop policy if exists "Participants read conversations" on public.conversations;
create policy "Participants read conversations" on public.conversations for select using (buyer_id = public.current_clerk_user_id() or seller_id = public.current_clerk_user_id());
drop policy if exists "Buyers create conversations" on public.conversations;
create policy "Buyers create conversations" on public.conversations for insert with check (buyer_id = public.current_clerk_user_id());
drop policy if exists "Participants update conversations" on public.conversations;
create policy "Participants update conversations" on public.conversations for update using (buyer_id = public.current_clerk_user_id() or seller_id = public.current_clerk_user_id()) with check (buyer_id = public.current_clerk_user_id() or seller_id = public.current_clerk_user_id());

drop policy if exists "Participants read messages" on public.messages;
create policy "Participants read messages" on public.messages for select using (
  exists (
    select 1 from public.conversations c
    where c.id = conversation_id
      and (c.buyer_id = public.current_clerk_user_id() or c.seller_id = public.current_clerk_user_id())
  )
);
drop policy if exists "Participants send messages" on public.messages;
create policy "Participants send messages" on public.messages for insert with check (
  sender_id = public.current_clerk_user_id()
  and exists (
    select 1 from public.conversations c
    where c.id = conversation_id
      and (c.buyer_id = public.current_clerk_user_id() or c.seller_id = public.current_clerk_user_id())
  )
);

insert into storage.buckets (id, name, public)
values ('listing-images', 'listing-images', true)
on conflict (id) do update set public = true;

drop policy if exists "Public listing images are readable" on storage.objects;
create policy "Public listing images are readable" on storage.objects for select using (bucket_id = 'listing-images');
drop policy if exists "Users upload their listing images" on storage.objects;
create policy "Users upload their listing images" on storage.objects for insert with check (
  bucket_id = 'listing-images' and (storage.foldername(name))[1] = public.current_clerk_user_id()
);
drop policy if exists "Users update their listing images" on storage.objects;
create policy "Users update their listing images" on storage.objects for update using (
  bucket_id = 'listing-images' and (storage.foldername(name))[1] = public.current_clerk_user_id()
);
drop policy if exists "Users delete their listing images" on storage.objects;
create policy "Users delete their listing images" on storage.objects for delete using (
  bucket_id = 'listing-images' and (storage.foldername(name))[1] = public.current_clerk_user_id()
);