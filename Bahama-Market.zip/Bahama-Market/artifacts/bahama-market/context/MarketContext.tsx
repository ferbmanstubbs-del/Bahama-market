import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth, useUser } from '@clerk/clerk-expo';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { AppState, ImageSourcePropType } from 'react-native';
import { Conversation, Listing, MarketMessage, Seller, seedConversations, seedListings } from '@/constants/market';
import { createAuthenticatedSupabaseClient, SupabaseAccessTokenGetter, uploadListingPhoto } from '@/lib/supabase';
import type { SupabaseClient } from '@supabase/supabase-js';

type NewListing = Pick<Listing, 'title' | 'price' | 'location' | 'category' | 'condition' | 'description'> & {
  image: ImageSourcePropType;
};

type ListingPatch = Partial<Omit<NewListing, 'image'>> & { image?: ImageSourcePropType };
type SyncStatus = 'loading' | 'syncing' | 'online' | 'offline';
type PendingOperationKind = 'create_listing' | 'update_listing' | 'delete_listing' | 'favorite' | 'conversation' | 'message';
type PendingOperation = {
  id: string;
  kind: PendingOperationKind;
  payload: Record<string, unknown>;
};

type MarketContextValue = {
  listings: Listing[];
  favorites: string[];
  conversations: Conversation[];
  currentUserId: string | null;
  syncStatus: SyncStatus;
  syncError: string | null;
  isSyncing: boolean;
  toggleFavorite: (id: string) => void;
  addListing: (listing: NewListing) => void;
  updateListing: (id: string, patch: ListingPatch) => Promise<void>;
  deleteListing: (id: string) => Promise<void>;
  startConversation: (listing: Listing) => string;
  sendMessage: (conversationId: string, text: string) => void;
  retrySync: () => Promise<void>;
};

const MarketContext = createContext<MarketContextValue | null>(null);
const LISTINGS_KEY = 'bahama-market-listings';
const FAVORITES_KEY = 'bahama-market-favorites';
const CONVERSATIONS_KEY = 'bahama-market-conversations';
const PENDING_KEY = 'bahama-market-pending-operations';

function cacheKey(key: string, scope: string) {
  return `${key}:${scope}`;
}

function asString(value: unknown, fallback = '') {
  return typeof value === 'string' && value.trim() ? value : fallback;
}

function asNumber(value: unknown, fallback = 0) {
  const number = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function imageUri(image: ImageSourcePropType): string | null {
  if (typeof image === 'object' && image !== null && 'uri' in image && typeof image.uri === 'string') {
    return image.uri;
  }
  return null;
}

function formatTimestamp(value: unknown) {
  const raw = asString(value);
  if (!raw) return 'Just now';
  const date = new Date(raw);
  if (Number.isNaN(date.getTime())) return raw;
  return date.toLocaleString([], { hour: 'numeric', minute: '2-digit' });
}

function sellerFromRow(row: Record<string, unknown> | undefined, sellerId: string): Seller {
  const displayName = asString(row?.display_name, 'Bahama Market seller');
  const nameParts = displayName.split(' ');
  return {
    id: sellerId,
    name: displayName,
    initials: asString(row?.initials, nameParts.map((part) => part[0]).join('').slice(0, 2).toUpperCase() || 'BM'),
    location: asString(row?.location, 'The Bahamas'),
    rating: asString(row?.rating, 'New'),
    sales: asString(row?.sales, '0 sales'),
    color: asString(row?.color, '#8CC9BF'),
  };
}

function listingFromRow(row: Record<string, unknown>, profiles: Map<string, Record<string, unknown>>): Listing {
  const sellerId = asString(row.seller_id, 'unknown-seller');
  const imageUrl = asString(row.image_url);
  return {
    id: asString(row.id),
    title: asString(row.title, 'Untitled listing'),
    price: asNumber(row.price),
    location: asString(row.location, 'The Bahamas'),
    category: asString(row.category, 'Home') as Listing['category'],
    condition: asString(row.condition, 'Good'),
    postedAt: formatTimestamp(row.created_at),
    description: asString(row.description, 'Message the seller for more details.'),
    image: imageUrl ? { uri: imageUrl } : seedListings[0].image,
    seller: sellerFromRow(profiles.get(sellerId), sellerId),
    isNew: Boolean(row.is_new),
  };
}

function listingRow(listing: Listing, sellerId: string, imageUrl: string | null) {
  return {
    id: listing.id,
    seller_id: sellerId,
    title: listing.title,
    price: listing.price,
    location: listing.location,
    category: listing.category,
    condition: listing.condition,
    description: listing.description,
    image_url: imageUrl,
    is_new: listing.isNew ?? true,
    updated_at: new Date().toISOString(),
  };
}

function messageFromRow(row: Record<string, unknown>, currentUserId: string): MarketMessage {
  return {
    id: asString(row.id),
    text: asString(row.text),
    fromMe: asString(row.sender_id) === currentUserId,
    time: formatTimestamp(row.created_at),
  };
}

function errorMessage(error: unknown) {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === 'object' && error !== null && 'message' in error && typeof error.message === 'string') return error.message;
  return 'Cloud sync is unavailable right now.';
}

export function MarketProvider({ children }: { children: React.ReactNode }) {
  const { isSignedIn, getToken } = useAuth();
  const { user } = useUser();
  const currentUserId = user?.id ?? null;
  const scope = currentUserId ?? 'guest';
  const [listings, setListings] = useState<Listing[]>(seedListings);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>(seedConversations);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('loading');
  const [syncError, setSyncError] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const pendingOperationsRef = useRef<PendingOperation[]>([]);
  const queueReadyRef = useRef(false);
  const flushPromiseRef = useRef<Promise<boolean> | null>(null);
  const getTokenRef = useRef(getToken);
  getTokenRef.current = getToken;
  const client = useMemo(() => {
    const getSupabaseToken: SupabaseAccessTokenGetter = async () => {
      if (!isSignedIn) return null;
      try {
        return await getTokenRef.current({ template: 'supabase' });
      } catch {
        return null;
      }
    };
    return createAuthenticatedSupabaseClient(getSupabaseToken);
  }, [isSignedIn]);

  const profilePayload = useMemo(() => currentUserId ? ({
    id: currentUserId,
    display_name: user?.fullName || user?.firstName || 'Bahama Market member',
    initials: `${user?.firstName?.[0] || 'B'}${user?.lastName?.[0] || 'M'}`.toUpperCase(),
    location: 'Nassau, NP',
    avatar_url: user?.imageUrl ?? null,
  }) : null, [currentUserId, user?.fullName, user?.firstName, user?.lastName, user?.imageUrl]);

  const ensureProfile = useCallback(async () => {
    if (!profilePayload) return;
    const response = await client.from('profiles').upsert(profilePayload, { onConflict: 'id' });
    if (response.error) throw response.error;
  }, [client, profilePayload]);

  const persistPending = useCallback(async () => {
    await AsyncStorage.setItem(cacheKey(PENDING_KEY, scope), JSON.stringify(pendingOperationsRef.current));
  }, [scope]);

  const performOperation = useCallback(async (operation: PendingOperation) => {
    if (!currentUserId) return;
    const payload = operation.payload;
    if (operation.kind === 'create_listing') {
      await ensureProfile();
      const listing = payload.listing as Listing;
      const localImageUri = imageUri(listing.image);
      const imageUrl = localImageUri ? await uploadListingPhoto(client, localImageUri, currentUserId, listing.id) : null;
      const { error } = await client.from('listings').upsert(listingRow(listing, currentUserId, imageUrl));
      if (error) throw error;
      return;
    }
    if (operation.kind === 'update_listing') {
      const id = asString(payload.id);
      const patch = { ...(payload.patch as Record<string, unknown>) };
      if (patch.image) {
        const localImageUri = imageUri(patch.image as ImageSourcePropType);
        patch.image_url = localImageUri ? await uploadListingPhoto(client, localImageUri, currentUserId, id) : null;
        delete patch.image;
      }
      const { error } = await client.from('listings').update({
        ...patch,
        updated_at: new Date().toISOString(),
      }).eq('id', id).eq('seller_id', currentUserId);
      if (error) throw error;
      return;
    }
    if (operation.kind === 'delete_listing') {
      const { error } = await client.from('listings').delete().eq('id', asString(payload.id)).eq('seller_id', currentUserId);
      if (error) throw error;
      return;
    }
    if (operation.kind === 'favorite') {
      const listingId = asString(payload.listingId);
      if (payload.favorite) {
        const { error } = await client.from('favorites').upsert({ user_id: currentUserId, listing_id: listingId });
        if (error) throw error;
      } else {
        const { error } = await client.from('favorites').delete().eq('user_id', currentUserId).eq('listing_id', listingId);
        if (error) throw error;
      }
      return;
    }
    if (operation.kind === 'conversation') {
      await ensureProfile();
      const { error } = await client.from('conversations').upsert(payload);
      if (error) throw error;
      return;
    }
    await ensureProfile();
    const { error } = await client.from('messages').upsert(payload);
    if (error) throw error;
    const conversationResponse = await client.from('conversations').update({
      last_message: asString(payload.text),
      updated_at: new Date().toISOString(),
    }).eq('id', asString(payload.conversation_id));
    if (conversationResponse.error) throw conversationResponse.error;
  }, [client, currentUserId, ensureProfile]);

  const flushPending = useCallback(async () => {
    if (!currentUserId || !queueReadyRef.current) return true;
    if (flushPromiseRef.current) return flushPromiseRef.current;
    const promise = (async () => {
      setSyncStatus('syncing');
      while (pendingOperationsRef.current.length) {
        const operation = pendingOperationsRef.current[0];
        try {
          await performOperation(operation);
          pendingOperationsRef.current.shift();
          await persistPending();
        } catch (error) {
          setSyncStatus('offline');
          setSyncError(errorMessage(error));
          return false;
        }
      }
      return true;
    })();
    flushPromiseRef.current = promise;
    try {
      return await promise;
    } finally {
      flushPromiseRef.current = null;
    }
  }, [currentUserId, performOperation, persistPending]);

  const enqueue = useCallback(async (operation: PendingOperation) => {
    if (!queueReadyRef.current) return;
    pendingOperationsRef.current = [...pendingOperationsRef.current, operation];
    await persistPending();
    void flushPending();
  }, [flushPending, persistPending]);

  const loadRemote = useCallback(async () => {
    const listingResponse = await client.from('listings').select('*').order('created_at', { ascending: false });
    if (listingResponse.error) throw listingResponse.error;
    const listingRows = (listingResponse.data ?? []) as Record<string, unknown>[];
    const sellerIds = [...new Set(listingRows.map((row) => asString(row.seller_id)).filter(Boolean))];
    const profilesResponse = sellerIds.length
      ? await client.from('profiles').select('*').in('id', sellerIds)
      : { data: [], error: null };
    if (profilesResponse.error) throw profilesResponse.error;
    const profiles = new Map(((profilesResponse.data ?? []) as Record<string, unknown>[]).map((row) => [asString(row.id), row]));
    setListings(listingRows.map((row) => listingFromRow(row, profiles)));

    if (!currentUserId) {
      setFavorites([]);
      setConversations([]);
      return;
    }

    await ensureProfile();

    const favoritesResponse = await client.from('favorites').select('listing_id').eq('user_id', currentUserId);
    if (favoritesResponse.error) throw favoritesResponse.error;
    setFavorites(((favoritesResponse.data ?? []) as Record<string, unknown>[]).map((row) => asString(row.listing_id)).filter(Boolean));

    const conversationsResponse = await client.from('conversations').select('*').or(`buyer_id.eq.${currentUserId},seller_id.eq.${currentUserId}`).order('updated_at', { ascending: false });
    if (conversationsResponse.error) throw conversationsResponse.error;
    const conversationRows = (conversationsResponse.data ?? []) as Record<string, unknown>[];
    const conversationIds = conversationRows.map((row) => asString(row.id)).filter(Boolean);
    const messageResponse = conversationIds.length
      ? await client.from('messages').select('*').in('conversation_id', conversationIds).order('created_at', { ascending: true })
      : { data: [], error: null };
    if (messageResponse.error) throw messageResponse.error;
    const messagesByConversation = new Map<string, MarketMessage[]>();
    for (const row of (messageResponse.data ?? []) as Record<string, unknown>[]) {
      const conversationId = asString(row.conversation_id);
      messagesByConversation.set(conversationId, [...(messagesByConversation.get(conversationId) ?? []), messageFromRow(row, currentUserId)]);
    }
    const listingsById = new Map(listingRows.map((row) => [asString(row.id), listingFromRow(row, profiles)]));
    setConversations(conversationRows.map((row) => {
      const listing = listingsById.get(asString(row.listing_id));
      const messages = messagesByConversation.get(asString(row.id)) ?? [];
      const sellerId = asString(row.seller_id, currentUserId);
      return {
        id: asString(row.id),
        listingId: asString(row.listing_id) || undefined,
        buyerId: asString(row.buyer_id) || undefined,
        seller: listing?.seller ?? sellerFromRow(profiles.get(sellerId), sellerId),
        listingTitle: listing?.title ?? 'Marketplace conversation',
        listingImage: listing?.image ?? seedListings[0].image,
        lastMessage: asString(row.last_message, messages.at(-1)?.text ?? 'Start the conversation'),
        timestamp: formatTimestamp(row.updated_at),
        unread: Boolean(row.unread),
        messages,
      };
    }));
  }, [client, currentUserId, ensureProfile]);

  const sync = useCallback(async () => {
    setSyncStatus('syncing');
    setSyncError(null);
    if (currentUserId) {
      try {
        await ensureProfile();
      } catch (error) {
        setSyncStatus('offline');
        setSyncError(errorMessage(error));
        return;
      }
    }
    if (!(await flushPending())) return;
    try {
      await loadRemote();
      setSyncStatus('online');
    } catch (error) {
      setSyncStatus('offline');
      setSyncError(errorMessage(error));
    }
  }, [currentUserId, ensureProfile, flushPending, loadRemote]);

  useEffect(() => {
    if (!currentUserId) return;
    const channel = client
      .channel(`bahama-market-${currentUserId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'listings' }, () => { void sync(); })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'favorites' }, () => { void sync(); })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'conversations' }, () => { void sync(); })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, () => { void sync(); })
      .subscribe();
    return () => { void client.removeChannel(channel); };
  }, [client, currentUserId, sync]);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active' && syncStatus === 'offline') void sync();
    });
    return () => subscription.remove();
  }, [sync, syncStatus]);

  useEffect(() => {
    let cancelled = false;
    queueReadyRef.current = false;
    setHydrated(false);
    setSyncStatus('loading');
    setSyncError(null);
    setListings(seedListings);
    setFavorites([]);
    setConversations(currentUserId ? seedConversations : []);
    pendingOperationsRef.current = [];
    Promise.all([
      AsyncStorage.getItem(cacheKey(LISTINGS_KEY, scope)),
      AsyncStorage.getItem(cacheKey(FAVORITES_KEY, scope)),
      AsyncStorage.getItem(cacheKey(CONVERSATIONS_KEY, scope)),
      AsyncStorage.getItem(cacheKey(PENDING_KEY, scope)),
    ]).then(async ([storedListings, storedFavorites, storedConversations, storedPending]) => {
      if (cancelled) return;
      try {
        if (storedListings) setListings(JSON.parse(storedListings) as Listing[]);
        if (storedFavorites) setFavorites(JSON.parse(storedFavorites) as string[]);
        if (storedConversations) setConversations(JSON.parse(storedConversations) as Conversation[]);
        pendingOperationsRef.current = storedPending ? JSON.parse(storedPending) as PendingOperation[] : [];
      } catch {
        pendingOperationsRef.current = [];
      }
      queueReadyRef.current = true;
      setHydrated(true);
      await sync();
    }).catch((error) => {
      if (cancelled) return;
      queueReadyRef.current = true;
      setHydrated(true);
      setSyncStatus('offline');
      setSyncError(errorMessage(error));
    });
    return () => {
      cancelled = true;
      queueReadyRef.current = false;
    };
  }, [currentUserId, scope, sync]);

  useEffect(() => {
    if (hydrated) void AsyncStorage.setItem(cacheKey(LISTINGS_KEY, scope), JSON.stringify(listings));
  }, [hydrated, listings, scope]);
  useEffect(() => {
    if (hydrated) void AsyncStorage.setItem(cacheKey(FAVORITES_KEY, scope), JSON.stringify(favorites));
  }, [favorites, hydrated, scope]);
  useEffect(() => {
    if (hydrated) void AsyncStorage.setItem(cacheKey(CONVERSATIONS_KEY, scope), JSON.stringify(conversations));
  }, [conversations, hydrated, scope]);

  const currentSeller = useMemo(() => ({
    id: currentUserId ?? 'me',
    name: user?.fullName || user?.firstName || 'Your listing',
    initials: `${user?.firstName?.[0] || 'Y'}${user?.lastName?.[0] || 'M'}`.toUpperCase(),
    location: 'Nassau, NP',
    rating: 'New',
    sales: '0 sales',
    color: '#8CC9BF',
  }), [currentUserId, user?.fullName, user?.firstName, user?.lastName]);

  const toggleFavorite = useCallback((id: string) => {
    const favorite = !favorites.includes(id);
    setFavorites((current) => favorite ? [...new Set([...current, id])] : current.filter((item) => item !== id));
    void enqueue({ id: `favorite-${id}-${Date.now()}`, kind: 'favorite', payload: { listingId: id, favorite } });
  }, [enqueue, favorites]);

  const addListing = useCallback((newListing: NewListing) => {
    const id = `listing-${Date.now()}`;
    const listing: Listing = {
      ...newListing,
      id,
      postedAt: 'Just now',
      seller: currentSeller,
      isNew: true,
    };
    setListings((current) => [listing, ...current]);
    void enqueue({ id: `create-${id}`, kind: 'create_listing', payload: { listing } });
  }, [currentSeller, enqueue]);

  const updateListing = useCallback(async (id: string, patch: ListingPatch) => {
    setListings((current) => current.map((listing) => listing.id === id ? {
      ...listing,
      ...patch,
      image: patch.image ?? listing.image,
    } : listing));
    await enqueue({ id: `update-${id}-${Date.now()}`, kind: 'update_listing', payload: { id, patch } });
  }, [enqueue]);

  const deleteListing = useCallback(async (id: string) => {
    setListings((current) => current.filter((listing) => listing.id !== id));
    setFavorites((current) => current.filter((listingId) => listingId !== id));
    await enqueue({ id: `delete-${id}-${Date.now()}`, kind: 'delete_listing', payload: { id } });
  }, [enqueue]);

  const startConversation = useCallback((listing: Listing) => {
    const existing = conversations.find((conversation) => conversation.listingId === listing.id || conversation.listingTitle === listing.title);
    if (existing) return existing.id;
    const id = `conversation-${listing.id}-${currentUserId ?? 'guest'}`;
    const conversation: Conversation = {
      id,
      listingId: listing.id,
      buyerId: currentUserId ?? undefined,
      seller: listing.seller,
      listingTitle: listing.title,
      listingImage: listing.image,
      lastMessage: 'Start the conversation',
      timestamp: 'Now',
      unread: false,
      messages: [],
    };
    setConversations((current) => [conversation, ...current]);
    if (currentUserId) {
      void enqueue({
        id: `conversation-${id}`,
        kind: 'conversation',
        payload: {
          id,
          listing_id: listing.id,
          buyer_id: currentUserId,
          seller_id: listing.seller.id,
          last_message: 'Start the conversation',
          unread: false,
          updated_at: new Date().toISOString(),
        },
      });
    }
    return id;
  }, [conversations, currentUserId, enqueue]);

  const sendMessage = useCallback((conversationId: string, text: string) => {
    if (!currentUserId) return;
    const message: MarketMessage = { id: `message-${Date.now()}`, text, fromMe: true, time: 'Now' };
    setConversations((current) => current.map((conversation) => conversation.id === conversationId ? {
      ...conversation,
      messages: [...conversation.messages, message],
      lastMessage: text,
      timestamp: 'Now',
    } : conversation));
    void enqueue({
      id: `message-${message.id}`,
      kind: 'message',
      payload: {
        id: message.id,
        conversation_id: conversationId,
        sender_id: currentUserId,
        text,
      },
    });
  }, [currentUserId, enqueue]);

  const retrySync = useCallback(async () => {
    await sync();
  }, [sync]);

  const value = useMemo<MarketContextValue>(() => ({
    listings,
    favorites,
    conversations,
    currentUserId,
    syncStatus,
    syncError,
    isSyncing: syncStatus === 'loading' || syncStatus === 'syncing',
    toggleFavorite,
    addListing,
    updateListing,
    deleteListing,
    startConversation,
    sendMessage,
    retrySync,
  }), [addListing, conversations, currentUserId, deleteListing, favorites, listings, retrySync, sendMessage, startConversation, syncError, syncStatus, toggleFavorite, updateListing]);

  return <MarketContext.Provider value={value}>{children}</MarketContext.Provider>;
}

export function useMarket() {
  const context = useContext(MarketContext);
  if (!context) throw new Error('useMarket must be used inside MarketProvider');
  return context;
}