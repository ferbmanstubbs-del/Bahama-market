---
name: Expo Clerk compatibility
description: Durable guidance for Clerk Expo dependency alignment and custom authentication flows.
---

For modern Clerk Core 3+ Expo apps, treat `@clerk/expo` as the owner of its transitive `@clerk/react` and `@clerk/shared` packages. Do not remove a transitive Clerk package to address a runtime error; resolve the compatible Clerk package set while preserving the auth provider. Inspect installed types before using custom sign-in factor methods, because examples from older Clerk versions can expose APIs the installed SDK does not have.

**Why:** A mismatched Clerk package set produced a runtime call to an export missing from the resolved shared package, while TypeScript still passed. Removing the transitive React package would have broken the Expo auth provider.

**How to apply:** When Clerk provider startup fails at runtime, inspect `pnpm why` and the resolved package exports first. Prefer a supported Expo SDK release whose Clerk dependencies align, then verify the app and auth routes render and typecheck.

For Bahama Market, the user explicitly chose the deprecated Core 2 package `@clerk/clerk-expo` over the modern `@clerk/expo` package after the migration tradeoff was explained. The legacy package uses `@clerk/clerk-react` and resource-based sign-in/sign-up methods.

**Why:** Future Clerk maintenance should preserve this explicit project choice rather than silently migrating the app back to Core 3.

**How to apply:** Keep Bahama Market's Clerk imports on `@clerk/clerk-expo` and retain its legacy auth flow unless the user asks to migrate.